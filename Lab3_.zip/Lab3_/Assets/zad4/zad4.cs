using UnityEngine;

public class zad4 : MonoBehaviour
{
    public float moveSpeed = 5f; // Pr?dko?? ruchu

    void Update()
    {
        // Pobieranie danych z klawiszy (strza?ki lub WSAD)
        float moveX = Input.GetAxis("Horizontal");
        float moveZ = Input.GetAxis("Vertical");

        // Tworzenie wektora ruchu
        Vector3 move = new Vector3(moveX, 0f, moveZ) * moveSpeed * Time.deltaTime;

        // Przemieszczanie obiektu gracza
        transform.Translate(move);
    }
}
