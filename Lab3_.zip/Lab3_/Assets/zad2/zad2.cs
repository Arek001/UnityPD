using UnityEngine;

public class zad2 : MonoBehaviour
{
    public float distancePerSecond = 5f; // predkosc
    private float distance = 0f; // droga
    private bool flag = true; // Flaga 

    void Update()
    {
        // Obliczanie ruchu na podstawie uplywajacego czasu
        float movement = distancePerSecond * Time.deltaTime;


        if (flag == true)
        {
            // Ruch do pozycji 10
            if (distance < 10f)
            {
                transform.Translate(movement, 0, 0);
                distance += movement;
            }
            else
            {
                // Zmiana flagi
                flag = false;
            }
        }
        else
        {
            // Ruch z powrotem do pozycji 0
            if (distance > 0f)
            {
                transform.Translate(-movement, 0, 0);
                distance -= movement;
            }
            else
            {

                flag = true;
            }
        }
    }
}

