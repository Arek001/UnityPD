using UnityEngine;

public class zad3 : MonoBehaviour
{
    public float distancePerSecond = 5f; // Pr?dkosc
    private float distance = 0f; // droga
  

    void Update()
    {
        // Obliczanie ruchu na podstawie up?ywaj?cego czasu
        float movement = distancePerSecond * Time.deltaTime;

        // Ruch wzd?u? bie??cego boku
        if (distance < 9f)
        {
            transform.Translate(Vector3.right * movement); // Ruch w prawo
            distance += movement;
        }
        else
        {
            // Po osi?gni?ciu 10 jednostek na bie??cym boku, obracamy si? o 90 stopni
            transform.Rotate(0, -90, 0); // Obr�t w osi Y o 90 stopni do gory

            distance = 0f; // Resetowanie przebytej odleg?o?ci dla nowego boku

            
        }
    }
}
