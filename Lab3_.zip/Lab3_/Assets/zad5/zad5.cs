using UnityEngine;
using System.Collections;

public class zad5 : MonoBehaviour
{
    // Prefabrykat, kt�ry ma by? instancjonowany
    public GameObject prefab;
    public int numberOfObjects = 10;    // Liczba obiekt�w do utworzenia
    public float spawnDelay = 2f;       // Op�?nienie mi?dzy spawnowaniem obiekt�w

    void Start()
    {
        StartCoroutine(SpawnObjects()); // Rozpocznij coroutine
    }

    IEnumerator SpawnObjects() // Coroutine do spawnowania obiekt�w
    {
        for (int i = 0; i < numberOfObjects; i++)
        {
            // Generowanie losowych wsp�?rz?dnych w zakresie od -5 do 5 (10 jednostek)
            float x = UnityEngine.Random.Range(-5f, 5f); // U?ycie UnityEngine.Random
            float z = UnityEngine.Random.Range(-5f, 5f); // U?ycie UnityEngine.Random
            Vector3 pos = new Vector3(x, 0, z); // Ustawianie pozycji

            // Instancjonowanie prefabrykatu
            Instantiate(prefab, pos, Quaternion.identity);

            // Czekaj przez spawnDelay sekundy
            yield return new WaitForSeconds(spawnDelay);
        }
    }
}
