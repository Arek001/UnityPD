
//kod do zadania 2,3


//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public class Example : MonoBehaviour
//{
//    private CharacterController controller;
//    private Vector3 playerVelocity;
//    private bool groundedPlayer;
//    public float playerSpeed = 15.0f;
//    private float jumpHeight = 4.0f;
//    private float gravityValue = -9.81f;

//    private void Start()
//    {
//        controller = gameObject.AddComponent<CharacterController>();
//    }

//    void Update()
//    {
//        groundedPlayer = controller.isGrounded;
//        if (groundedPlayer && playerVelocity.y < 0)
//        {
//            playerVelocity.y = 0f;
//        }



//        Vector3 move = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
//        controller.Move(move * Time.deltaTime * playerSpeed);

//        if (move != Vector3.zero)
//        {
//            gameObject.transform.forward = move;
//        }

//        // Changes the height position of the player..
//        if (Input.GetButtonDown("Jump") && groundedPlayer)
//        {
//            playerVelocity.y += Mathf.Sqrt(jumpHeight * -3.0f * gravityValue);
//        }

//        playerVelocity.y += gravityValue * Time.deltaTime;
//        controller.Move(playerVelocity * Time.deltaTime);
//    }
//}



//kod do zad 4


using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Example : MonoBehaviour
{
    private CharacterController controller;
    private Vector3 playerVelocity;
    private bool groundedPlayer;
    public float playerSpeed = 15.0f;
    private float jumpHeight = 4.0f;
    private float gravityValue = -9.81f;

    
    public Transform player; 
    public float sensitivity = 200f;
    private float xRotation = 0f;

    private void Start()
    {
        controller = gameObject.AddComponent<CharacterController>();

      
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        // Sprawdzanie, czy gracz jest na ziemi
        groundedPlayer = controller.isGrounded;
        if (groundedPlayer && playerVelocity.y < 0)
        {
            playerVelocity.y = 0f;
        }

        // Ruch gracza za pomoc? W, A, S, D 
        Vector3 move = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical"));
        controller.Move(move * Time.deltaTime * playerSpeed);


        // pobieramy wartosci dla obu osi ruchu myszy
        float mouseX = Input.GetAxis("Mouse X") * sensitivity * Time.deltaTime;
        float mouseY = Input.GetAxis("Mouse Y") * sensitivity * Time.deltaTime;

        // Obrot postaci wokol osi Y 
        transform.Rotate(Vector3.up * mouseX);

        // Obrot kamery wokol osi X (gora/dol)
        xRotation -= mouseY;
        xRotation = Mathf.Clamp(xRotation, -90f, 90f); // Ograniczenie kata patrzenia w gore i dol
        player.localRotation = Quaternion.Euler(xRotation, 0f, 0f);

        // Skok
        if (Input.GetButtonDown("Jump") && groundedPlayer)
        {
            playerVelocity.y += Mathf.Sqrt(jumpHeight * -3.0f * gravityValue);
        }

        // Grawitacja
        playerVelocity.y += gravityValue * Time.deltaTime;
        controller.Move(playerVelocity * Time.deltaTime);
    }
}
