
using UnityEngine;
//zad6
public class PlayerCollision : MonoBehaviour
{
    
        

        private void OnControllerColliderHit(ControllerColliderHit hit)
        {
            if (hit.gameObject.name == "przeszkoda")
            {
                Debug.Log("Wykryto kolizje");
            }
    
       
    }
}

