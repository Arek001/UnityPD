using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//zad1
public class Elevator : MonoBehaviour
{
    public float platformSpeed = 2f;
    public float distance = 10f; 
    private Vector3 startPosition;
    private Vector3 targetPosition;
    private bool isMoving = false; 
    private bool movingToTarget = true; // Kierunek ruchu platformy
    private bool hasMoved = false; 

    void Start()
    {
        // Ustawienie start i meta
        startPosition = transform.position;
        targetPosition = startPosition + transform.right * distance;
    }

    void Update()
    {
        if (isMoving && !hasMoved)
        {
            
            Vector3 destination = movingToTarget ? targetPosition : startPosition;

            // Ruch platformy do mety
            transform.position = Vector3.MoveTowards(transform.position, destination, platformSpeed * Time.deltaTime);

            // jesli meta zmiana kierunku
            if (Vector3.Distance(transform.position, destination) < 0.1f)
            {
                if (!movingToTarget)
                {
                    
                    isMoving = false;
                    hasMoved = true;
                }
                else
                {
                  
                    movingToTarget = false;
                }
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        
        if (other.gameObject.CompareTag("Player") && !hasMoved)
        {
            isMoving = true;
        }
    }
}
