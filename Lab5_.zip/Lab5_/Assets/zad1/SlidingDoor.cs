using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//zad2
public class SlidingDoor : MonoBehaviour
{
    public float platformSpeed = 2f;
    public float distance = 2f; 
    private Vector3 startPosition;
    private Vector3 targetPosition;
    private bool isMoving = false; 
    private bool movingToTarget = true; 
    private bool hasMoved = false; 

    void Start()
    {
       
        startPosition = transform.position;
        targetPosition = startPosition + transform.right * distance;
    }

    void Update()
    {
        if (isMoving && !hasMoved)
        {
            
            Vector3 destination = movingToTarget ? targetPosition : startPosition;

          
            transform.position = Vector3.MoveTowards(transform.position, destination, platformSpeed * Time.deltaTime);

           
            if (Vector3.Distance(transform.position, destination) < 0.1f)
            {
                if (!movingToTarget)
                {
                    
                    isMoving = false;
                    hasMoved = true;
                }
                else
                {
                   
                    movingToTarget = false;
                }
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
      
        if (other.gameObject.CompareTag("Player") && !hasMoved)
        {
            isMoving = true;
        }
    }
}
