using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;
//zad5
public class Elevator2 : MonoBehaviour
{

    public float force = 10.0f; 
    public Rigidbody rb; 

    void Start()
    {
     
        if (rb == null)
        {
            rb = GetComponent<Rigidbody>(); 
        }
    }

    private void OnTriggerEnter(Collider other)
    {
       
        if (other.CompareTag("Player")) 
        {
            
            rb.AddForce(Vector3.up * force, ForceMode.Impulse);
           
        }
    }
}
